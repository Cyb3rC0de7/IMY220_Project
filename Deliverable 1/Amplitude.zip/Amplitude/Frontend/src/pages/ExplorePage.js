//u21669849, Qwinton Knocklein
import React from 'react';
//import '../styles/ExplorePage.css';

const ExplorePage = () => {
  return (
    <div className="explore-container">
      <h1>Explore Playlists and Music</h1>
      <p>Discover new music, trending playlists, and much more.</p>
      {/* You can add components here to display music or playlist categories */}
    </div>
  );
};

export default ExplorePage;
